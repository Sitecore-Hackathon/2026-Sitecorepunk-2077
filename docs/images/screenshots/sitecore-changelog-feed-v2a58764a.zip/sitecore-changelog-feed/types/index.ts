export interface ChangelogEntry {
  id: string;
  title: string;
  link: string;
  description: string;
  pubDate: string;
  product: string;
  category: string;
}

export interface ChangelogApiResponse {
  entries: ChangelogEntry[];
  error?: string;
}

export interface FilterState {
  product: string;
  category: string;
}