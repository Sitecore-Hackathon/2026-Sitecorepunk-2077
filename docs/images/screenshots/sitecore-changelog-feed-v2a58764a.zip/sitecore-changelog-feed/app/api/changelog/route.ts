import { NextResponse } from "next/server";

function extractCDATA(text: string): string {
  const cdataMatch = text.match(/<!\[CDATA\[([\s\S]*?)\]\]>/);
  return cdataMatch ? cdataMatch[1].trim() : text.trim();
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, "").trim();
}

function extractCategory(title: string, description: string): string {
  const text = `${title} ${description}`.toLowerCase();

  const categoryPatterns: Array<{ pattern: RegExp; label: string }> = [
    { pattern: /\bbug\s*fix/i, label: "Bug Fix" },
    { pattern: /\bfix(?:ed|es)?\b/i, label: "Bug Fix" },
    { pattern: /\bnew\s*feature/i, label: "New Feature" },
    { pattern: /\bintroduc/i, label: "New Feature" },
    { pattern: /\blaunch/i, label: "New Feature" },
    { pattern: /\bimprove/i, label: "Improvement" },
    { pattern: /\benhance/i, label: "Improvement" },
    { pattern: /\boptimiz/i, label: "Improvement" },
    { pattern: /\bupdat/i, label: "Improvement" },
    { pattern: /\bdeprecat/i, label: "Deprecation" },
    { pattern: /\bremov/i, label: "Deprecation" },
    { pattern: /\bbreak(?:ing)?\s*change/i, label: "Breaking Change" },
    { pattern: /\bsecur/i, label: "Security" },
    { pattern: /\bperform/i, label: "Performance" },
  ];

  for (const { pattern, label } of categoryPatterns) {
    if (pattern.test(text)) {
      return label;
    }
  }

  return "Update";
}

function extractProduct(title: string, description: string, categories: string[]): string {
  const text = `${title} ${description} ${categories.join(" ")}`;

  const productPatterns: Array<{ pattern: RegExp; label: string }> = [
    { pattern: /\bXM\s*Cloud\b/i, label: "XM Cloud" },
    { pattern: /\bContent\s*Hub\s*ONE\b/i, label: "Content Hub ONE" },
    { pattern: /\bContent\s*Hub\b/i, label: "Content Hub" },
    { pattern: /\bOrderCloud\b/i, label: "OrderCloud" },
    { pattern: /\bSitecore\s*Search\b/i, label: "Search" },
    { pattern: /\bSearch\b/i, label: "Search" },
    { pattern: /\bSend\b/i, label: "Send" },
    { pattern: /\bPersonalize\b/i, label: "Personalize" },
    { pattern: /\bCDP\b/i, label: "CDP" },
    { pattern: /\bConnect\b/i, label: "Connect" },
    { pattern: /\bDiscover\b/i, label: "Discover" },
    { pattern: /\bExperience\s*Edge\b/i, label: "Experience Edge" },
    { pattern: /\bExperience\s*Manager\b/i, label: "Experience Manager" },
    { pattern: /\bExperience\s*Platform\b/i, label: "Experience Platform" },
    { pattern: /\bExperience\s*Commerce\b/i, label: "Experience Commerce" },
    { pattern: /\bManaged\s*Cloud\b/i, label: "Managed Cloud" },
    { pattern: /\bCompos(?:able\s*)?DXP\b/i, label: "Composable DXP" },
    { pattern: /\bStream\b/i, label: "Stream" },
  ];

  for (const { pattern, label } of productPatterns) {
    if (pattern.test(text)) {
      return label;
    }
  }

  return "Sitecore";
}

function parseRssXml(xml: string): Array<{
  id: string;
  title: string;
  link: string;
  description: string;
  pubDate: string;
  product: string;
  category: string;
}> {
  const entries: Array<{
    id: string;
    title: string;
    link: string;
    description: string;
    pubDate: string;
    product: string;
    category: string;
  }> = [];

  // Try RSS <item> elements
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match: RegExpExecArray | null;

  while ((match = itemRegex.exec(xml)) !== null) {
    const itemXml = match[1];

    const titleMatch = itemXml.match(/<title>([\s\S]*?)<\/title>/);
    const linkMatch = itemXml.match(/<link>([\s\S]*?)<\/link>/);
    const descMatch = itemXml.match(/<description>([\s\S]*?)<\/description>/);
    const pubDateMatch = itemXml.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
    const guidMatch = itemXml.match(/<guid[^>]*>([\s\S]*?)<\/guid>/);

    // Collect category tags
    const categoryRegex = /<category[^>]*>([\s\S]*?)<\/category>/gi;
    const categories: string[] = [];
    let catMatch: RegExpExecArray | null;
    while ((catMatch = categoryRegex.exec(itemXml)) !== null) {
      categories.push(extractCDATA(catMatch[1]));
    }

    const rawTitle = titleMatch ? extractCDATA(titleMatch[1]) : "Untitled";
    const rawDesc = descMatch ? extractCDATA(descMatch[1]) : "";
    const cleanTitle = stripHtml(rawTitle);
    const cleanDesc = stripHtml(rawDesc);
    const link = linkMatch ? extractCDATA(linkMatch[1]) : "";
    const pubDate = pubDateMatch ? extractCDATA(pubDateMatch[1]) : "";
    const id = guidMatch ? extractCDATA(guidMatch[1]) : link || `entry-${entries.length}`;

    const product = extractProduct(cleanTitle, cleanDesc, categories);
    const category = extractCategory(cleanTitle, cleanDesc);

    entries.push({
      id,
      title: cleanTitle,
      link,
      description: cleanDesc.substring(0, 200),
      pubDate,
      product,
      category,
    });
  }

  // Fallback: try Atom <entry> elements
  if (entries.length === 0) {
    const entryRegex = /<entry>([\s\S]*?)<\/entry>/gi;
    while ((match = entryRegex.exec(xml)) !== null) {
      const entryXml = match[1];

      const titleMatch = entryXml.match(/<title[^>]*>([\s\S]*?)<\/title>/);
      const linkMatch = entryXml.match(/<link[^>]*href=["']([^"']*)["'][^>]*\/?>/);
      const summaryMatch = entryXml.match(/<summary[^>]*>([\s\S]*?)<\/summary>/) ||
        entryXml.match(/<content[^>]*>([\s\S]*?)<\/content>/);
      const updatedMatch = entryXml.match(/<updated>([\s\S]*?)<\/updated>/) ||
        entryXml.match(/<published>([\s\S]*?)<\/published>/);
      const idMatch = entryXml.match(/<id>([\s\S]*?)<\/id>/);

      const categoryRegex = /<category[^>]*term=["']([^"']*)["'][^>]*\/?>/gi;
      const categories: string[] = [];
      let catMatch: RegExpExecArray | null;
      while ((catMatch = categoryRegex.exec(entryXml)) !== null) {
        categories.push(catMatch[1]);
      }

      const rawTitle = titleMatch ? extractCDATA(titleMatch[1]) : "Untitled";
      const rawDesc = summaryMatch ? extractCDATA(summaryMatch[1]) : "";
      const cleanTitle = stripHtml(rawTitle);
      const cleanDesc = stripHtml(rawDesc);
      const link = linkMatch ? linkMatch[1] : "";
      const pubDate = updatedMatch ? extractCDATA(updatedMatch[1]) : "";
      const id = idMatch ? extractCDATA(idMatch[1]) : link || `entry-${entries.length}`;

      const product = extractProduct(cleanTitle, cleanDesc, categories);
      const category = extractCategory(cleanTitle, cleanDesc);

      entries.push({
        id,
        title: cleanTitle,
        link,
        description: cleanDesc.substring(0, 200),
        pubDate,
        product,
        category,
      });
    }
  }

  return entries;
}

export async function GET(): Promise<NextResponse> {
  try {
    // Primary: Sitecore changelog RSS feed
    const feedUrl = process.env.CHANGELOG_FEED_URL || "https://developers.sitecore.com/changelog/rss";

    const response = await fetch(feedUrl, {
      headers: {
        Accept: "application/rss+xml, application/xml, application/atom+xml, text/xml, */*",
        "User-Agent": "SitecoreChangelogWidget/1.0",
      },
      next: { revalidate: 0 },
    });

    if (!response.ok) {
      return NextResponse.json(
        { entries: [], error: `Failed to fetch feed: ${response.status} ${response.statusText}` },
        { status: 502 }
      );
    }

    const xml = await response.text();

    if (!xml || xml.trim().length === 0) {
      return NextResponse.json(
        { entries: [], error: "Empty response from feed" },
        { status: 502 }
      );
    }

    const entries = parseRssXml(xml);

    // Sort by date descending
    entries.sort((a, b) => {
      const dateA = new Date(a.pubDate).getTime();
      const dateB = new Date(b.pubDate).getTime();
      if (isNaN(dateA) && isNaN(dateB)) return 0;
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateB - dateA;
    });

    return NextResponse.json({ entries });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Internal server error";
    return NextResponse.json({ entries: [], error: message }, { status: 500 });
  }
}