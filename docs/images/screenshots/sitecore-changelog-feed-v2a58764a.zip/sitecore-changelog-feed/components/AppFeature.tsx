"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import type { ClientSDK } from "@sitecore-marketplace-sdk/client";
import type { ChangelogEntry, ChangelogApiResponse, FilterState } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ErrorDisplay } from "@/components/ErrorDisplay";
import { RefreshCw, ExternalLink, Clock, ChevronDown, Filter } from "lucide-react";

const ITEMS_PER_PAGE = 10;

const CATEGORY_COLORS: Record<string, string> = {
  "New Feature": "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200",
  Improvement: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  "Bug Fix": "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  Deprecation: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  "Breaking Change": "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  Security: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  Performance: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200",
  Update: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
};

function formatDate(dateStr: string): string {
  if (!dateStr) return "Unknown date";
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return "Unknown date";
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function formatTimestamp(date: Date): string {
  return date.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AppFeature({ client }: { client: ClientSDK }): JSX.Element {
  const [entries, setEntries] = useState<ChangelogEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [visibleCount, setVisibleCount] = useState<number>(ITEMS_PER_PAGE);
  const [filters, setFilters] = useState<FilterState>({ product: "All", category: "All" });

  // Suppress unused variable lint — client is required by the interface
  void client;

  const fetchChangelog = useCallback(async (isManualRefresh = false): Promise<void> => {
    if (isManualRefresh) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }
    setError(null);

    try {
      const response = await fetch("/api/changelog");
      const data: ChangelogApiResponse = await response.json();

      if (data.error && data.entries.length === 0) {
        setError(data.error);
      } else {
        setEntries(data.entries);
        setLastRefreshed(new Date());
        if (data.error) {
          console.warn("Changelog feed warning:", data.error);
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to fetch changelog";
      setError(message);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchChangelog(false);
  }, [fetchChangelog]);

  const products = useMemo<string[]>(() => {
    const productSet = new Set(entries.map((e) => e.product));
    return ["All", ...Array.from(productSet).sort()];
  }, [entries]);

  const categories = useMemo<string[]>(() => {
    const categorySet = new Set(entries.map((e) => e.category));
    return ["All", ...Array.from(categorySet).sort()];
  }, [entries]);

  const filteredEntries = useMemo<ChangelogEntry[]>(() => {
    return entries.filter((entry) => {
      const matchProduct = filters.product === "All" || entry.product === filters.product;
      const matchCategory = filters.category === "All" || entry.category === filters.category;
      return matchProduct && matchCategory;
    });
  }, [entries, filters]);

  const visibleEntries = useMemo<ChangelogEntry[]>(() => {
    return filteredEntries.slice(0, visibleCount);
  }, [filteredEntries, visibleCount]);

  const hasMore = visibleCount < filteredEntries.length;

  const handleLoadMore = (): void => {
    setVisibleCount((prev) => prev + ITEMS_PER_PAGE);
  };

  const handleFilterChange = (key: keyof FilterState, value: string): void => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setVisibleCount(ITEMS_PER_PAGE);
  };

  const handleRefresh = (): void => {
    fetchChangelog(true);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="flex gap-3">
          <Skeleton className="h-9 w-40" />
          <Skeleton className="h-9 w-40" />
        </div>
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  if (error && entries.length === 0) {
    return (
      <ErrorDisplay
        title="Failed to load changelog"
        message={error}
        onRetry={() => fetchChangelog(false)}
      />
    );
  }

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Sitecore Changelog</h2>
          <p className="text-sm text-muted-foreground">
            Latest updates across Sitecore products
          </p>
        </div>
        <div className="flex items-center gap-2">
          {lastRefreshed && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatTimestamp(lastRefreshed)}
            </span>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5">
          <Filter className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Filters:</span>
        </div>
        <div className="relative">
          <select
            value={filters.product}
            onChange={(e) => handleFilterChange("product", e.target.value)}
            className="appearance-none bg-background border border-input rounded-md px-3 py-1.5 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-ring cursor-pointer"
          >
            {products.map((product) => (
              <option key={product} value={product}>
                {product === "All" ? "All Products" : product}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
        </div>
        <div className="relative">
          <select
            value={filters.category}
            onChange={(e) => handleFilterChange("category", e.target.value)}
            className="appearance-none bg-background border border-input rounded-md px-3 py-1.5 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-ring cursor-pointer"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category === "All" ? "All Categories" : category}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
        </div>
        {(filters.product !== "All" || filters.category !== "All") && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setFilters({ product: "All", category: "All" });
              setVisibleCount(ITEMS_PER_PAGE);
            }}
            className="text-xs"
          >
            Clear filters
          </Button>
        )}
        <span className="text-xs text-muted-foreground ml-auto">
          {filteredEntries.length} {filteredEntries.length === 1 ? "entry" : "entries"}
        </span>
      </div>

      {/* Error banner (non-blocking) */}
      {error && entries.length > 0 && (
        <div className="rounded-md bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 px-3 py-2 text-sm text-amber-800 dark:text-amber-200">
          Feed may be outdated: {error}
        </div>
      )}

      {/* Entries list */}
      {filteredEntries.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-sm text-muted-foreground">
              No entries match the selected filters.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {visibleEntries.map((entry) => (
            <a
              key={entry.id}
              href={entry.link}
              target="_blank"
              rel="noopener noreferrer"
              className="block group"
            >
              <Card className="transition-colors hover:bg-accent/50 cursor-pointer">
                <CardContent className="py-3 px-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary" className="text-xs font-medium shrink-0">
                          {entry.product}
                        </Badge>
                        <span
                          className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                            CATEGORY_COLORS[entry.category] || CATEGORY_COLORS["Update"]
                          }`}
                        >
                          {entry.category}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatDate(entry.pubDate)}
                        </span>
                      </div>
                      <h3 className="text-sm font-medium leading-snug group-hover:underline truncate">
                        {entry.title}
                      </h3>
                      {entry.description && (
                        <p className="text-xs text-muted-foreground line-clamp-1">
                          {entry.description}
                        </p>
                      )}
                    </div>
                    <ExternalLink className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </CardContent>
              </Card>
            </a>
          ))}
        </div>
      )}

      {/* Load more */}
      {hasMore && (
        <div className="flex justify-center pt-2">
          <Button variant="outline" size="sm" onClick={handleLoadMore}>
            Load more ({filteredEntries.length - visibleCount} remaining)
          </Button>
        </div>
      )}
    </div>
  );
}

export default AppFeature;